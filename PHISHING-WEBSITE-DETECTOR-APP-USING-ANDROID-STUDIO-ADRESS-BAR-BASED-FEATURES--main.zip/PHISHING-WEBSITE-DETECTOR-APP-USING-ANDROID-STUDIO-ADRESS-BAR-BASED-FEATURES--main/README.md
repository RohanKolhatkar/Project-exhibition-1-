# PHISHING-WEBSITE-DETECTOR-APP-USING-ANDROID-STUDIO-ADRESS-BAR-BASED-FEATURES-
Our goal in this project is to create a phishing detecting android application which can detect whether the website accessed by a user is a phishing website or not using its URL. Our application is user-friendly and can be used by the user offline.
This is our Univariety[VIT Bhopal] Project was made in 3rd SEM
